# UploadChunk

A mixin for validating unknown serializers' fields.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**file** | **file** | A chunk of the uploaded file. | 
**sha256** | **str** | The SHA-256 checksum of the chunk if available. | [optional] 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



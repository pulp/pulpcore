# FilesystemExport

Serializer for FilesystemExports.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**task** | **str** | A URI of the task that ran the Export. | [optional] 
**publication** | **str** | A URI of the publication to be exported. | [optional] 
**repository_version** | **str** | A URI of the repository version export. | [optional] 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



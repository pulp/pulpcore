# PulpImportCheckResponse

Return the response to a PulpImport import-check call.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**toc** | [**EvaluationResponse**](EvaluationResponse) | Evaluation of proposed &#39;toc&#39; file for PulpImport | [optional] 
**path** | [**EvaluationResponse**](EvaluationResponse) | Evaluation of proposed &#39;path&#39; file for PulpImport | [optional] 
**repo_mapping** | [**EvaluationResponse**](EvaluationResponse) | Evaluation of proposed &#39;repo_mapping&#39; file for PulpImport | [optional] 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



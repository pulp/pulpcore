# OrphansCleanup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content_hrefs** | **list[object]** | Will delete specified content and associated Artifacts if they are orphans. | [optional] 
**orphan_protection_time** | **int** | The time in minutes for how long Pulp will hold orphan Content and Artifacts before they become candidates for deletion by this orphan cleanup task. This should ideally be longer than your longest running task otherwise any content created during that task could be cleaned up before the task finishes. If not specified, default is used from settings which is 1440 minutes (24 hours) | [optional] [default to 0]

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



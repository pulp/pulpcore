# OrphansCleanup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content_hrefs** | **list[object]** | Will delete specified content and associated Artifacts if they are orphans. | [optional] 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



# PulpImport

Serializer for call to import into Pulp.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**path** | **str** | Path to export that will be imported. | [optional] 
**toc** | **str** | Path to a table-of-contents file describing chunks to be validated, reassembled, and imported. | [optional] 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



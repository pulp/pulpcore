# TaskGroupOperationResponse

Serializer for asynchronous operations that return a task group.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**task_group** | **str** | The href of the task group. | 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



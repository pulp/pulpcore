# UploadChunkResponse

A mixin for validating unknown serializers' fields.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**offset** | **int** |  | [optional] [readonly] 
**size** | **int** |  | [optional] [readonly] 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



# PermissionResponse

Serializer for User/Group object permission.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pulp_href** | **str** |  | [optional] [readonly] 
**id** | **int** |  | [optional] [readonly] 
**permission** | **str** |  | [optional] [readonly] 
**obj** | **str** | Content object. | [optional] [readonly] 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



# UploadCommit

A mixin for validating unknown serializers' fields.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sha256** | **str** | The expected sha256 checksum for the file. | 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



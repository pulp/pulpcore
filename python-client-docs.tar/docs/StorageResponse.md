# StorageResponse

Serializer for information about the storage system
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **int** | Total number of bytes | 
**used** | **int** | Number of bytes in use | 
**free** | **int** | Number of free bytes | 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



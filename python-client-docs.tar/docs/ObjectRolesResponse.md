# ObjectRolesResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**roles** | [**list[NestedRoleResponse]**](NestedRoleResponse) |  | 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



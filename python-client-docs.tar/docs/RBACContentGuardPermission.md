# RBACContentGuardPermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**usernames** | **list[object]** |  | [optional] [default to []]
**groupnames** | **list[object]** |  | [optional] [default to []]

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



# AccessPolicy

Serializer for AccessPolicy.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**permissions_assignment** | **list[object]** | List of callables that define the new permissions to be created for new objects. | 
**statements** | **list[object]** | List of policy statements defining the policy. | 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



# PatchedRole

Serializer for Role.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | The name of this role. | [optional] 
**description** | **str** | An optional description. | [optional] 
**permissions** | **list[str]** | List of permissions defining the role. | [optional] 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



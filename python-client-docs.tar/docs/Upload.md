# Upload

Serializer for chunked uploads.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**size** | **int** | The size of the upload in bytes. | 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



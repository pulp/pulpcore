# AsyncOperationResponse

Serializer for asynchronous operations.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**task** | **str** | The href of the task. | 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



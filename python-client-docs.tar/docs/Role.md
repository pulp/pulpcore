# Role

Serializer for Role.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | The name of this role. | 
**description** | **str** | An optional description. | [optional] 
**permissions** | **list[str]** | List of permissions defining the role. | 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



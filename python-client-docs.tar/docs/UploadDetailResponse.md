# UploadDetailResponse

Serializer for chunked uploads.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pulp_href** | **str** |  | [optional] [readonly] 
**pulp_created** | **datetime** | Timestamp of creation. | [optional] [readonly] 
**size** | **int** | The size of the upload in bytes. | 
**completed** | **datetime** | Timestamp when upload is committed. | [optional] [readonly] 
**chunks** | [**list[UploadChunkResponse]**](UploadChunkResponse) |  | [optional] [readonly] 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



# Repair

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**verify_checksums** | **bool** | Will verify that the checksum of all stored files matches what saved in the database. Otherwise only the existence of the files will be checked. Enabled by default | [optional] [default to True]

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



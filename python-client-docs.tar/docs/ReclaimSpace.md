# ReclaimSpace

Serializer for reclaim disk space operation.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**repo_hrefs** | **list[object]** | Will reclaim space for the specified list of repos. | 
**repo_versions_keeplist** | **list[str]** | Will exclude repo versions from space reclaim. | [optional] 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)



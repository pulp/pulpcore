# StatusResponse

Serializer for the status information of the app
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**versions** | [**list[VersionResponse]**](VersionResponse) | Version information of Pulp components | 
**online_workers** | [**list[WorkerResponse]**](WorkerResponse) | List of online workers known to the application. An online worker is actively heartbeating and can respond to new work | 
**online_content_apps** | [**list[ContentAppStatusResponse]**](ContentAppStatusResponse) | List of online content apps known to the application. An online content app is actively heartbeating and can serve data to clients | 
**database_connection** | [**DatabaseConnectionResponse**](DatabaseConnectionResponse) | Database connection information | 
**redis_connection** | [**RedisConnectionResponse**](RedisConnectionResponse) | Redis connection information | [optional] 
**storage** | [**StorageResponse**](StorageResponse) | Storage information | [optional] 

[[Back to Model list]](../#documentation-for-models) [[Back to API list]](../#documentation-for-api-endpoints) [[Back to HOME]](../)


